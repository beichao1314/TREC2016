#coding=utf8
'''
Created on 2017��2��20��

@author: Peter
'''
from bs4 import BeautifulSoup
import codecs
import argparse

parse = argparse.ArgumentParser(description="some information here")
parse.add_argument('--file', action='store', dest='file')
#parse.add_argument('--output', action='store', dest='output')
arg = parse.parse_args()

def get_seg(src_name,wrt_name):
    src_file = codecs.open(src_name,'r','utf-8')
    wrt_file = codecs.open(wrt_name,'w','utf-8')
    source  = src_file.read()
    soup = BeautifulSoup(source)
    seg_list = soup.find_all('seg')
    cnt = 1 
    for seg in seg_list:
        wrt_file.write(seg.get_text()+'\n')
        cnt += 1
    print(cnt)


get_seg(arg.file, arg.file.replace('xml','txt'))