# -*- coding: utf-8 -*-
import codecs
import argparse

parse = argparse.ArgumentParser(description="some information here")
parse.add_argument('--file', action='store', dest='file')
parse.add_argument('--src', action='store', dest='src')
parse.add_argument('--tgt', action='store', dest='tgt')
parse.add_argument('--output', action='store', dest='output')
arg = parse.parse_args()

if __name__ == "__main__":
    fr = codecs.open(arg.file, 'rb', encoding='utf8')
    fw = codecs.open(arg.output, 'wb', encoding='utf8')
    line = fr.readline()
    while line:
        line = line.strip()
        if line:
            st = '__opt_src_%s __opt_tgt_%s '%(arg.src, arg.tgt)
            fw.write(st + line + '\n')
        line = fr.readline()
    fr.close()
    fw.close()
   
