#!/bin/bash

for src in de en nl it ro; do
  for tgt in de en nl it ro; do
    python add_lang_token.py --file train/train.tags.$src-$tgt.bpe.$src --src $src --tgt $tgt --output add_lang_token/train.tags.$src-$tgt.bpe.add.$src
  done
done
