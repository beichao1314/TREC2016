for src in de nl it ro en
  do
    for tgt in de nl it ro en
      do
        ~/tools/mosesdecoder/scripts/tokenizer/normalize-punctuation.perl -l $src < $src-$tgt/IWSLT17.TED.tst2017.mltlng.$src-$tgt.$src.txt > $src-$tgt/tst2017.np.$src
        ~/tools/mosesdecoder/scripts/tokenizer/tokenizer.perl -a -l $src < $src-$tgt/tst2017.np.$src > $src-$tgt/tst2017.tok.$src
        ~/tools/mosesdecoder/scripts/recaser/truecase.perl --model ../../../../multi_data/4wbpe/model/truecase-model.$src < $src-$tgt/tst2017.tok.$src > $src-$tgt/tst2017.tc.$src
        ~/tools/subword-nmt/apply_bpe.py -c ../../../../multi_data/4wbpe/model/de-en-it-ro-nl.bpe < $src-$tgt/tst2017.tc.$src > $src-$tgt/tst2017.bpe.$src
        python add_lang_token.py --file $src-$tgt/tst2017.bpe.$src --src $src --tgt $tgt --output $src-$tgt/tst2017.bpe.$src.add
    done
done
