return {
  PAD = 1,
  UNK = 2,
  BOS = 3,
  EOS = 4,

  PAD_WORD = '<blank>',
  UNK_WORD = '<unk>',
  BOS_WORD = '<s>',
  EOS_WORD = '</s>'
}
