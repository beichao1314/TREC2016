return {
  joiner_marker = '￭',
  joiner_marker_substitute = '■',
  feat_marker = '￨',
  feat_marker_substitute = '│',
  BOT = "<w>",
  EOT = "</w>"
}
